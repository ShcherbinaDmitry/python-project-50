def generate_diff(filepath1, filepath2):
    print('Generating diff')
