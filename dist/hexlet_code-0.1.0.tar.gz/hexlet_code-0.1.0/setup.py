# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.engine', 'gendiff.engine.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': "# Hexlet tests and linter status:\n[![Actions Status](https://github.com/ShcherbinaDmitry/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/ShcherbinaDmitry/python-project-50/actions)\n\n### Codeclimate maintainability status:\n[![Maintainability](https://api.codeclimate.com/v1/badges/7743b8938e967a062392/maintainability)](https://codeclimate.com/github/ShcherbinaDmitry/python-project-50/maintainability)\n\n### Codeclimate Test Coverage status:\n[![Test Coverage](https://api.codeclimate.com/v1/badges/7743b8938e967a062392/test_coverage)](https://codeclimate.com/github/ShcherbinaDmitry/python-project-50/test_coverage)\n\n### Examples\n#### Getting version and help of gendiff package\n[![asciicast](https://asciinema.org/a/gNDe3q4eEVh1TevomPzGTgOI3.svg)](https://asciinema.org/a/gNDe3q4eEVh1TevomPzGTgOI3)\n\n#### Comparing two '.json' files with nested objects\n[![asciicast](https://asciinema.org/a/fO5zSHOT3aUuM5xblnk4ck0Du.svg)](https://asciinema.org/a/fO5zSHOT3aUuM5xblnk4ck0Du)\n\n#### Comparing two '.yml' files with nested objects\n[![asciicast](https://asciinema.org/a/KQCEOO45zr2K1r4z3uaNaXXRs.svg)](https://asciinema.org/a/KQCEOO45zr2K1r4z3uaNaXXRs)\n\n#### Comparing files using plain formatter\n[![asciicast](https://asciinema.org/a/5HxSSzD6NhLCp2ISGf5mIitlS.svg)](https://asciinema.org/a/5HxSSzD6NhLCp2ISGf5mIitlS)\n\n#### Comparing files using JSON formatter\n[![asciicast](https://asciinema.org/a/eFG3czJetYODCy4oGcvOVAH5P.svg)](https://asciinema.org/a/eFG3czJetYODCy4oGcvOVAH5P)",
    'author': 'Dmitry Shcherbina',
    'author_email': 'shcherbinadmitry@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
